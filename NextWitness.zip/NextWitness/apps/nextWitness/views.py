from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, HttpResponse, redirect
from .models import *
from django.contrib import messages
import bcrypt

# Create your views here. These connect to the templates/html, but must be accessed from the sister urls dir.
# This is where I store my methods.
# the client gets information with GET, but when it submits a form it will use POST. 
# Refreshing the browser will yield the same GET or POST method previously used.
# Render will go to the HTML, but Request will go to the method in views
def index(request):
    return render(request, 'nextWitness/index.html')

def create(request):
    errors = User.objects.regValidator(request.POST)
    if len(errors):
        for tag, error in errors.items():
            messages.error(request, error)
        return redirect('/')
    first_name = request.POST['first_name']
    last_name = request.POST['last_name']
    email = request.POST['email']
    password = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt())
    user = User.objects.create(first_name= first_name, last_name= last_name, email= email, password= password)
    user.save()
    request.session['user_id'] = user.id
    request.session['user_name'] = user.first_name
    return redirect("/wishes")

def index2(request):
    return render(request, 'nextWitness/index-2.html')

def validate_login(request):
    errors = User.objects.log_validator(request.POST)
    if len(errors):
        for tag, error in errors.items():
            messages.error(request, error)
        return redirect('/')
    user = User.objects.get(email=request.POST['email'])  
    request.session['user_id'] = user.id
    request.session['user_name'] = user.first_name
    return redirect("/wishes")

def success(request):
    user = User.objects.get(id=request.session['user_id'])
    context = {
        'user': user
    }
    messages.success(request, "Sucessfully registered or (logged in)!")
    return render(request,'nextWitness/wishes.html', context)

def logout(request):
    request.session.clear()
    return redirect("/")

def wishes(request):  
    context = {
        'allWishes': Wish.objects.all(),
        'user': User.objects.get(id=request.session['user_id'])
    } 
    return render(request,'nextWitness/wishes.html', context)

def wishes_new(request):
    # context={
    #     'thisQuote': Quote.objects.get(id=quote_id),
    # }
    return render(request,'nextWitness/wishes_new.html')

def process_wish(request): 
    errors = Wish.objects.wishValidator(request.POST)
    if len(errors):
        for tag, error in errors.items():
            messages.error(request, error)
        return redirect('/wishes/new')
    my_wish=request.POST['my_wish'] 
    description=request.POST['description']
    creator = User.objects.get(id=request.session['user_id'])
    wish = Wish.objects.create(my_wish=my_wish,description=description, creator=creator) 
    return redirect('/wishes')


def edit_wish(request, wish_id):
    context={
        'wish': Wish.objects.get(id=wish_id),
        'user': User.objects.get(id=request.session['user_id'])
    }
    return render(request,'nextWitness/edit_wish.html', context)

def process_edit(request):
    errors = Wish.objects.wishEditValidator(request.POST)
    id = request.POST['id']
    if len(errors):
        for tag, error in errors.items():
            messages.error(request, error)
        return redirect(f'/wishes/{id}')
    wish=Wish.objects.get(id=request.POST['id'])
    wish.my_wish=request.POST['title'] 
    wish.description=request.POST['desc']
    wish.save()
    return redirect('/wishes')

def delete_wish(request, wish_id):
    destroy= Wish.objects.get(id=wish_id)
    destroy.delete()
    return redirect('/wishes')

def granted_wish(request, wish_id):
    context={
        'thisWish': Wish.objects.get(id=wish_id),
        'allWishes': Wish.objects.all(),
        'user': User.objects.get(id=request.session['user_id'])
    }
    wish_to_update = Wish.objects.get(id=wish_id)
    wish_to_update.granted = True
    wish_to_update.save()
    return redirect('/wishes', context)