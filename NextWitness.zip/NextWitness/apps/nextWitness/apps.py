from django.apps import AppConfig


class NextwitnessConfig(AppConfig):
    name = 'nextWitness'
