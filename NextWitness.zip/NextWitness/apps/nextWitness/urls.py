from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.index),
    url(r'^create$', views.create),
    url(r'^validate_login$', views.validate_login),
    url(r'^logout$', views.logout),
    url(r'^success$', views.success),
    url(r'^wishes$', views.wishes),
    url(r'^wishes/new$', views.wishes_new),
    url(r'^process_wish$', views.process_wish),
    url(r'^wishes/(?P<wish_id>\d+)$', views.edit_wish),
    url(r'^process_edit$', views.process_edit),
    url(r'^granted_wish/(?P<wish_id>\d+)$', views.granted_wish),
    url(r'^delete_wish/(?P<wish_id>\d+)$', views.delete_wish),
    url(r'^index2$', views.index2),

]